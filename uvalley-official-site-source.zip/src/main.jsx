import React from 'react';
import { createRoot } from 'react-dom/client';
import { AnimatePresence, motion, useScroll, useSpring, useTransform } from 'framer-motion';
import {
  ArrowRight,
  BadgeCheck,
  BriefcaseBusiness,
  Bus,
  CalendarCheck,
  Car,
  ChevronRight,
  Clock3,
  Facebook,
  Gem,
  Hotel,
  Instagram,
  Linkedin,
  Mail,
  MapPin,
  Menu,
  Moon,
  Navigation,
  Phone,
  Plane,
  Quote,
  Route,
  ShieldCheck,
  Sparkles,
  Star,
  Sun,
  Users,
  X,
} from 'lucide-react';
import './styles.css';

const images = {
  hero: '/assets/hero-luxury.svg',
  about: '/assets/fleet-luxury.svg',
  cabin: '/assets/fleet-sedan.svg',
  sedan: '/assets/fleet-sedan.svg',
  suv: '/assets/fleet-suv.svg',
  luxury: '/assets/fleet-luxury.svg',
  traveller: '/assets/fleet-traveller.svg',
  bus: '/assets/fleet-bus.svg',
  event: '/assets/hero-luxury.svg',
  visionary: '/assets/vinod-kumar-pandit.png',
};

const navItems = [
  ['Home', 'home'],
  ['About Us', 'about'],
  ['Services', 'services'],
  ['Become Partner', 'partner'],
  ['Vehicles', 'vehicles'],
  ['Contact', 'contact'],
];

const stats = [
  ['500+', 'Trips'],
  ['100+', 'Vehicles'],
  ['24/7', 'Support'],
  ['Trusted', 'by Clients'],
];

const services = [
  [BriefcaseBusiness, 'Corporate Travel', 'Executive mobility, team movement and monthly business travel plans.'],
  [Plane, 'Airport Transfers', 'On-time pickups, flight-aware scheduling and quiet premium arrivals.'],
  [CalendarCheck, 'Wedding & Event Transport', 'Coordinated luxury convoys for guests, hosts and VIPs.'],
  [Route, 'Outstation Trips', 'Comfortable intercity journeys with verified drivers and clean vehicles.'],
  [BadgeCheck, 'Chauffeur Services', 'Professional drivers trained for privacy, etiquette and reliability.'],
  [Gem, 'Luxury Car Rentals', 'Premium sedans and statement vehicles for elevated occasions.'],
  [Users, 'Group Travel', 'Seamless movement for families, teams, conferences and retreats.'],
  [Hotel, 'Hotel & Tourism Transport', 'Curated city transfers and tourism routes for hospitality partners.'],
];

const vehicles = [
  {
    category: 'Sedans',
    image: images.sedan,
    name: 'Executive Sedan',
    seats: '4 seats',
    features: ['Climate control', 'Luggage space', 'Business class comfort'],
    price: 'Custom quote',
  },
  {
    category: 'SUVs',
    image: images.suv,
    name: 'Premium SUV',
    seats: '6 seats',
    features: ['High clearance', 'Captain seats', 'Long route ready'],
    price: 'Custom quote',
  },
  {
    category: 'Luxury Cars',
    image: images.luxury,
    name: 'Luxury Signature',
    seats: '4 seats',
    features: ['VIP interiors', 'Priority driver', 'Event presence'],
    price: 'Custom quote',
  },
  {
    category: 'Tempo Travellers',
    image: images.traveller,
    name: 'Tempo Traveller',
    seats: '12-17 seats',
    features: ['Group comfort', 'AC cabin', 'Tour package ready'],
    price: 'Custom quote',
  },
  {
    category: 'Buses',
    image: images.bus,
    name: 'Premium Coach',
    seats: '30-45 seats',
    features: ['Fleet scheduling', 'Large groups', 'Event logistics'],
    price: 'Custom quote',
  },
];

const logos = ['UVALLEY', 'UVALLEY', 'UVALLEY', 'UVALLEY', 'UVALLEY', 'UVALLEY'];
const filters = ['All', 'Sedans', 'SUVs', 'Luxury Cars', 'Tempo Travellers', 'Buses'];
const contactDetails = {
  phone: '+91 9810303956',
  phoneHref: 'tel:+919810303956',
  email: 'vinodpandit@uvalley.co.in',
  emailHref: 'mailto:vinodpandit@uvalley.co.in',
  address: 'UValley Management Services LLP, Samalkha, Pushpanjali Farms, New Delhi, Delhi, 110097',
};

function App() {
  const [dark, setDark] = React.useState(true);
  const [menuOpen, setMenuOpen] = React.useState(false);
  const [filter, setFilter] = React.useState('All');
  const [loading, setLoading] = React.useState(true);
  const { scrollYProgress } = useScroll();
  const progress = useSpring(scrollYProgress, { stiffness: 160, damping: 26 });

  React.useEffect(() => {
    document.documentElement.classList.toggle('dark', dark);
  }, [dark]);

  React.useEffect(() => {
    const timer = setTimeout(() => setLoading(false), 3000);
    return () => clearTimeout(timer);
  }, []);

  const filteredVehicles = filter === 'All' ? vehicles : vehicles.filter((vehicle) => vehicle.category === filter);

  return (
    <div className="min-h-screen overflow-x-hidden bg-frost text-slate-950 transition-colors duration-500 dark:bg-ink dark:text-white">
      <AnimatePresence>
        {loading && (
          <motion.div
            className="fixed inset-0 z-[100] overflow-hidden bg-ink"
            exit={{ opacity: 0 }}
            transition={{ duration: 0.75, ease: 'easeInOut' }}
          >
            <IntroLoader />
          </motion.div>
        )}
      </AnimatePresence>

      <motion.div className="fixed left-0 right-0 top-0 z-[90] h-1 origin-left bg-gradient-to-r from-aurora via-plasma to-sky-300" style={{ scaleX: progress }} />
      <Navbar dark={dark} setDark={setDark} menuOpen={menuOpen} setMenuOpen={setMenuOpen} />

      <main>
        <Hero />
        <Stats />
        <Featured />
        <About />
        <Visionary />
        <Services />
        <Partner />
        <Vehicles filter={filter} setFilter={setFilter} filteredVehicles={filteredVehicles} />
        <Testimonials />
        <LogoMarquee />
        <Contact />
        <FinalCta />
      </main>
      <Footer />
    </div>
  );
}

function IntroLoader() {
  return (
    <div className="intro-loader">
      <div className="intro-glow intro-glow-one" />
      <div className="intro-glow intro-glow-two" />
      <div className="intro-road">
        <span />
        <span />
        <span />
      </div>
      <div className="intro-stage">
        <div className="intro-copy">
          <span className="intro-kicker">Premium mobility across India</span>
          <div className="intro-word" aria-label="UVALLEY">
            {'UVALLEY'.split('').map((letter, index) => (
              <span key={letter} style={{ '--letter-delay': `${0.22 + index * 0.13}s` }}>{letter}</span>
            ))}
          </div>
        </div>
        <div className="intro-car-wrap" aria-hidden="true">
          <svg viewBox="0 0 460 150" className="intro-car">
            <defs>
              <linearGradient id="introCarPaint" x1="0" x2="1">
                <stop offset="0" stopColor="#0f172a" />
                <stop offset="0.42" stopColor="#f8fafc" />
                <stop offset="0.7" stopColor="#8b5cf6" />
                <stop offset="1" stopColor="#050510" />
              </linearGradient>
            </defs>
            <ellipse cx="228" cy="126" rx="185" ry="18" fill="#000" opacity=".45" />
            <path d="M39 93 C55 56 96 42 151 40 L204 13 C242 -4 306 0 354 25 L414 58 C438 67 450 80 454 95 L435 119 L55 120Z" fill="url(#introCarPaint)" />
            <path d="M160 44 L211 20 C245 10 298 13 334 31 L375 58 L151 59Z" fill="#e0f2fe" opacity=".65" />
            <path d="M62 91 L125 84 C151 82 158 99 134 106 L50 108Z" fill="#f8fafc" />
            <path d="M392 92 L452 98 L437 108 L365 105 C350 101 365 90 392 92Z" fill="#c084fc" />
            <circle cx="126" cy="121" r="28" fill="#020617" />
            <circle cx="126" cy="121" r="15" fill="#8b5cf6" className="intro-wheel" />
            <circle cx="366" cy="121" r="28" fill="#020617" />
            <circle cx="366" cy="121" r="15" fill="#8b5cf6" className="intro-wheel" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Navbar({ dark, setDark, menuOpen, setMenuOpen }) {
  return (
    <header className="fixed left-0 right-0 top-4 z-50 px-4">
      <nav className="mx-auto flex max-w-7xl items-center justify-between rounded-full border border-white/15 bg-white/70 px-4 py-3 shadow-glass backdrop-blur-2xl dark:bg-black/35">
        <a href="#home" className="flex items-center gap-3" aria-label="UValley home">
          <span className="grid h-10 w-10 place-items-center rounded-full bg-gradient-to-br from-white to-purple-200 text-sm font-black text-ink shadow-glow">UV</span>
          <span className="font-display text-lg font-semibold tracking-wide">UValley</span>
        </a>
        <div className="hidden items-center gap-1 lg:flex">
          {navItems.map(([label, id]) => (
            <a key={id} href={`#${id}`} className="rounded-full px-4 py-2 text-sm text-slate-700 transition hover:bg-slate-900/5 hover:text-slate-950 dark:text-white/70 dark:hover:bg-white/10 dark:hover:text-white">
              {label}
            </a>
          ))}
        </div>
        <div className="flex items-center gap-2">
          <button onClick={() => setDark(!dark)} className="icon-button" aria-label="Toggle dark mode">
            {dark ? <Sun size={18} /> : <Moon size={18} />}
          </button>
          <a href="#contact" className="hidden rounded-full bg-slate-950 px-5 py-2.5 text-sm font-semibold text-white shadow-glow transition hover:scale-105 dark:bg-white dark:text-ink sm:inline-flex">
            Book Now
          </a>
          <button onClick={() => setMenuOpen(!menuOpen)} className="icon-button lg:hidden" aria-label="Toggle navigation">
            {menuOpen ? <X size={20} /> : <Menu size={20} />}
          </button>
        </div>
      </nav>
      <AnimatePresence>
        {menuOpen && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="mx-auto mt-3 max-w-7xl rounded-3xl border border-white/15 bg-white/90 p-4 shadow-glass backdrop-blur-2xl dark:bg-black/100 lg:hidden"
          >
            {navItems.map(([label, id]) => (
              <a key={id} onClick={() => setMenuOpen(false)} href={`#${id}`} className="block rounded-2xl px-4 py-3 text-sm text-slate-700 hover:bg-slate-950/5 dark:text-white/100 dark:hover:bg-white/10">
                {label}
              </a>
            ))}
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}

function Hero() {
  const { scrollY } = useScroll();
  const y = useTransform(scrollY, [0, 700], [0, 160]);
  return (
    <section id="home" className="relative min-h-screen overflow-hidden bg-ink">
      <motion.img src={images.hero} alt="Luxury vehicle at night" className="absolute inset-0 h-full w-full object-cover opacity-60" style={{ y }} />
      <div className="absolute inset-0 bg-[linear-gradient(90deg,rgba(5,5,16,.94),rgba(5,5,16,.58),rgba(5,5,16,.78))]" />
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_72%_28%,rgba(139,92,246,.34),transparent_34%)]" />
      <div className="relative mx-auto flex min-h-screen max-w-7xl items-center px-5 pb-20 pt-32">
        <div className="max-w-4xl">
          <motion.div initial={{ opacity: 0, y: 24 }} animate={{ opacity: 1, y: 0 }} className="mb-6 inline-flex items-center gap-2 rounded-full border border-white/15 bg-white/10 px-4 py-2 text-sm text-white/100 backdrop-blur-xl">
            <Sparkles size={16} className="text-champagne" /> Luxury mobility, engineered for India
          </motion.div>
          <motion.h1 initial={{ opacity: 0, y: 34 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }} className="font-display text-5xl font-semibold leading-[0.95] text-white sm:text-6xl lg:text-8xl">
            Premium Travel Experience Across India
          </motion.h1>
          <motion.p initial={{ opacity: 0, y: 26 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }} className="mt-7 max-w-2xl text-lg leading-8 text-white/75 sm:text-xl">
            Luxury rides, professional drivers and seamless journeys for individuals, businesses and events.
          </motion.p>
          <motion.div initial={{ opacity: 0, y: 24 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }} className="mt-10 flex flex-col gap-4 sm:flex-row">
            <a href="#contact" className="premium-button">Book Now <ArrowRight size={18} /></a>
            <a href="#partner" className="secondary-button">Become a Travel Partner <ChevronRight size={18} /></a>
          </motion.div>
        </div>
      </div>
      <div className="pointer-events-none absolute bottom-0 left-0 right-0 h-28 bg-gradient-to-t from-ink to-transparent" />
    </section>
  );
}

function SectionHeader({ eyebrow, title, text }) {
  return (
    <div className="mx-auto mb-12 max-w-3xl text-center">
      <span className="text-sm font-semibold uppercase tracking-[0.28em] text-aurora">{eyebrow}</span>
      <h2 className="mt-4 font-display text-3xl font-semibold text-slate-950 dark:text-white sm:text-5xl">{title}</h2>
      {text && <p className="mt-5 text-base leading-7 text-slate-600 dark:text-white/60">{text}</p>}
    </div>
  );
}

function Reveal({ children, className = '' }) {
  return (
    <motion.div initial={{ opacity: 0, y: 32 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true, margin: '-80px' }} transition={{ duration: 0.65 }} className={className}>
      {children}
    </motion.div>
  );
}

function Stats() {
  return (
    <section className="relative bg-radial-premium py-14">
      <div className="mx-auto grid max-w-7xl grid-cols-2 gap-4 px-5 lg:grid-cols-4">
        {stats.map(([value, label], index) => (
          <Reveal key={label} className="glass-panel p-6 text-center" >
            <motion.div initial={{ scale: 0.9 }} whileInView={{ scale: 1 }} transition={{ delay: index * 0.06 }} className="font-display text-3xl font-semibold text-white sm:text-5xl">
              {value}
            </motion.div>
            <div className="mt-2 text-sm uppercase tracking-[0.2em] text-white/60">{label}</div>
          </Reveal>
        ))}
      </div>
    </section>
  );
}

function Featured() {
  return (
    <section className="section">
      <SectionHeader eyebrow="Signature Fleet" title="Arrive With Presence" text="A refined collection of vehicles selected for comfort, condition, driver quality and the kind of arrival that feels effortless." />
      <div className="mx-auto grid max-w-7xl gap-5 px-5 lg:grid-cols-3">
        {vehicles.slice(0, 3).map((vehicle) => <VehicleCard key={vehicle.name} vehicle={vehicle} featured />)}
      </div>
    </section>
  );
}

function About() {
  const timeline = ['Founded with premium intercity routes', 'Built verified driver network', 'Expanded into events and corporate mobility', 'Scaling partner fleets across India'];
  return (
    <section id="about" className="section overflow-hidden">
      <div className="mx-auto grid max-w-7xl items-center gap-10 px-5 lg:grid-cols-[1fr_1.1fr]">
        <Reveal className="relative">
          <img src={images.about} alt="Premium sports car" className="h-[520px] w-full rounded-[2rem] object-cover shadow-glass" />
          <div className="absolute -bottom-6 right-5 max-w-xs rounded-3xl border border-white/20 bg-white/15 p-5 text-white shadow-glass backdrop-blur-xl">
            <div className="flex items-center gap-2 text-champagne"><ShieldCheck size={18} /> Verified network</div>
            <p className="mt-2 text-sm text-white/70">Every trip is planned for safety, punctuality and polish.</p>
          </div>
        </Reveal>
        <Reveal>
          <span className="text-sm font-semibold uppercase tracking-[0.28em] text-aurora">About UValley</span>
          <h2 className="mt-4 font-display text-4xl font-semibold sm:text-5xl">A luxury transport brand built for modern Indian journeys.</h2>
          <p className="mt-6 leading-8 text-slate-600 dark:text-white/60">UValley blends premium vehicles, disciplined operations and warm hospitality to serve business leaders, families, hotels, event planners and travel partners. Our vision is simple: make every journey feel dependable, private and elevated.</p>
          <div className="mt-8 grid gap-4 sm:grid-cols-2">
            <InfoTile icon={Navigation} title="Mission" text="Deliver seamless travel with professional drivers and concierge-level care." />
            <InfoTile icon={Star} title="Vision" text="Become India’s most trusted premium mobility partner." />
          </div>
          <div className="mt-9 space-y-4">
            {timeline.map((item, index) => (
              <motion.div key={item} initial={{ opacity: 0, x: 24 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }} transition={{ delay: index * 0.08 }} className="flex items-center gap-4">
                <span className="grid h-9 w-9 shrink-0 place-items-center rounded-full border border-aurora/40 bg-aurora/10 text-sm text-aurora">{index + 1}</span>
                <span className="text-slate-700 dark:text-white/70">{item}</span>
              </motion.div>
            ))}
          </div>
        </Reveal>
      </div>
    </section>
  );
}

function Visionary() {
  return (
    <section className="section overflow-hidden bg-slate-100/70 dark:bg-white/[0.03]">
      <div className="mx-auto max-w-7xl px-5">
        <Reveal>
          <div className="mx-auto mb-12 max-w-4xl text-center">
            <h2 className="font-display text-3xl font-semibold text-slate-950 dark:text-white sm:text-5xl">
              <span className="text-aurora">Visionaries</span> Behind the Journey
            </h2>
          </div>
        </Reveal>
        <div className="grid items-center gap-10 lg:grid-cols-[1.05fr_0.95fr]">
          <Reveal className="rounded-[2rem] border border-slate-200 bg-white p-7 shadow-sm dark:border-white/10 dark:bg-white/[0.055] sm:p-10">
            <Quote className="h-14 w-14 text-aurora" fill="currentColor" />
            <p className="mt-8 max-w-3xl text-2xl leading-[1.65] text-slate-600 dark:text-white/68">
              At UValley, we bridge the gap between traditional rentals and modern technology. Our mission is to provide a transparent, safe, and tech-driven ecosystem that ensures excellence in every executive journey.
            </p>
            <div className="mt-9">
              <a href="https://www.linkedin.com/in/vinod-pandit-44565531/" target="_blank" rel="noreferrer" className="inline-flex rounded-none bg-[#7a1025] px-6 py-3 font-display text-lg font-semibold text-white shadow-glow transition hover:-translate-y-1 hover:bg-aurora">
                Vinod Kumar Pandit
              </a>
              <p className="mt-5 text-base font-medium uppercase tracking-[0.2em] text-slate-500 dark:text-white/50">CEO</p>
            </div>
          </Reveal>
          <Reveal className="relative mx-auto w-full max-w-lg">
            <div className="absolute inset-4 rounded-full bg-aurora/20 blur-3xl" />
            <div className="relative aspect-square overflow-hidden rounded-full border border-white/20 bg-slate-200 shadow-glass dark:bg-white/10">
              <img src={images.visionary} alt="Vinod Kumar Pandit, CEO of UValley" className="h-full w-full object-cover object-[50%_28%]" />
            </div>
          </Reveal>
        </div>
      </div>
    </section>
  );
}

function InfoTile({ icon: Icon, title, text }) {
  return (
    <div className="rounded-3xl border border-slate-200 bg-white/70 p-5 shadow-sm backdrop-blur-xl dark:border-white/10 dark:bg-white/5">
      <Icon className="text-aurora" size={24} />
      <h3 className="mt-4 font-display text-lg font-semibold">{title}</h3>
      <p className="mt-2 text-sm leading-6 text-slate-600 dark:text-white/60">{text}</p>
    </div>
  );
}

function Services() {
  return (
    <section id="services" className="section bg-slate-100/70 dark:bg-white/[0.03]">
      <SectionHeader eyebrow="Services" title="Travel Designed Around Your Occasion" text="From a quiet airport pickup to complex event logistics, UValley keeps the experience premium at every touchpoint." />
      <div className="mx-auto grid max-w-7xl gap-5 px-5 sm:grid-cols-2 lg:grid-cols-4">
        {services.map(([Icon, title, text]) => (
          <Reveal key={title} className="group rounded-3xl border border-slate-200 bg-white p-6 shadow-sm transition duration-300 hover:-translate-y-2 hover:border-aurora/50 hover:shadow-glow dark:border-white/10 dark:bg-white/[0.055]">
            <div className="grid h-12 w-12 place-items-center rounded-2xl bg-aurora/10 text-aurora transition group-hover:bg-aurora group-hover:text-white">
              <Icon size={24} />
            </div>
            <h3 className="mt-6 font-display text-xl font-semibold">{title}</h3>
            <p className="mt-3 min-h-[72px] text-sm leading-6 text-slate-600 dark:text-white/60">{text}</p>
            <button className="mt-6 inline-flex items-center gap-2 text-sm font-semibold text-aurora">Learn More <ArrowRight size={16} /></button>
          </Reveal>
        ))}
      </div>
    </section>
  );
}

function Partner() {
  return (
    <section id="partner" className="section relative overflow-hidden bg-ink text-white">
      <img src={images.cabin} alt="Luxury car detail" className="absolute inset-0 h-full w-full object-cover opacity-18" />
      <div className="absolute inset-0 bg-radial-premium opacity-95" />
      <div className="relative mx-auto grid max-w-7xl gap-10 px-5 lg:grid-cols-[0.9fr_1.1fr]">
        <Reveal>
          <span className="text-sm font-semibold uppercase tracking-[0.28em] text-champagne">Become a Travel Partner</span>
          <h2 className="mt-4 font-display text-4xl font-semibold sm:text-5xl">Grow with a premium mobility network.</h2>
          <p className="mt-6 leading-8 text-white/60">Join UValley to access higher-value bookings, corporate demand, event routes and operational support designed for quality fleet owners.</p>
          <div className="mt-8 grid gap-4 sm:grid-cols-3">
            {['Premium leads', 'Flexible routes', 'Brand trust'].map((item) => <div key={item} className="glass-panel p-4 text-center text-sm">{item}</div>)}
          </div>
        </Reveal>
        <Reveal>
          <form className="rounded-[2rem] border border-white/15 bg-white/10 p-5 shadow-glass backdrop-blur-2xl sm:p-7">
            <div className="grid gap-4 sm:grid-cols-2">
              {['Name', 'Phone', 'Email', 'City', 'Vehicle Type', 'Experience'].map((field) => (
                <label key={field} className="block">
                  <span className="mb-2 block text-xs uppercase tracking-[0.18em] text-white/50">{field}</span>
                  <input className="form-input" type={field === 'Email' ? 'email' : 'text'} placeholder={field} />
                </label>
              ))}
            </div>
            <button type="button" className="premium-button mt-6 w-full justify-center">Join Now <ArrowRight size={18} /></button>
          </form>
        </Reveal>
      </div>
    </section>
  );
}

function Vehicles({ filter, setFilter, filteredVehicles }) {
  return (
    <section id="vehicles" className="section">
      <SectionHeader eyebrow="Our Vehicles" title="Premium Fleet Showcase" text="Filter by occasion and select the right experience, from executive sedans to coaches for large group movement." />
      <div className="mx-auto mb-9 flex max-w-7xl gap-3 overflow-x-auto px-5 pb-2">
        {filters.map((item) => (
          <button key={item} onClick={() => setFilter(item)} className={`shrink-0 rounded-full border px-5 py-2.5 text-sm transition ${filter === item ? 'border-aurora bg-aurora text-white shadow-glow' : 'border-slate-200 bg-white/70 text-slate-700 hover:border-aurora/50 dark:border-white/10 dark:bg-white/5 dark:text-white/70'}`}>
            {item}
          </button>
        ))}
      </div>
      <div className="mx-auto grid max-w-7xl gap-5 px-5 md:grid-cols-2 xl:grid-cols-3">
        <AnimatePresence mode="popLayout">
          {filteredVehicles.map((vehicle) => <VehicleCard key={vehicle.name} vehicle={vehicle} />)}
        </AnimatePresence>
      </div>
      <FleetBrandMarquee />
    </section>
  );
}

function FleetBrandMarquee() {
  const marks = ['toyota', 'bmw', 'suzuki', 'hyundai', 'mercedes'];

  return (
    <div className="mx-auto mt-14 max-w-7xl overflow-hidden px-5">
      <div className="relative rounded-[2rem] border border-slate-200 bg-white/70 py-5 shadow-sm backdrop-blur-xl dark:border-white/10 dark:bg-white/[0.055]">
        <div className="pointer-events-none absolute inset-y-0 left-0 z-10 w-24 bg-gradient-to-r from-white via-white/90 to-transparent dark:from-[#0a0a14] dark:via-[#0a0a14]/90" />
        <div className="pointer-events-none absolute inset-y-0 right-0 z-10 w-24 bg-gradient-to-l from-white via-white/90 to-transparent dark:from-[#0a0a14] dark:via-[#0a0a14]/90" />
        <motion.div animate={{ x: ['0%', '-50%'] }} transition={{ duration: 24, repeat: Infinity, ease: 'linear' }} className="flex w-max items-center gap-5 px-8">
          {[...marks, ...marks, ...marks].map((mark, index) => (
            <div key={`${mark}-${index}`} className="grid h-20 w-28 place-items-center rounded-3xl border border-slate-200 bg-slate-950 text-white shadow-sm transition hover:border-aurora/60 hover:shadow-glow dark:border-white/10 dark:bg-white/8" aria-label={`${mark} logo`}>
              <BrandMark type={mark} />
            </div>
          ))}
        </motion.div>
      </div>
    </div>
  );
}

function BrandMark({ type }) {
  const common = 'h-12 w-12 text-white';

  if (type === 'volkswagen') {
    return (
      <svg viewBox="0 0 64 64" className={common} role="img" aria-hidden="true">
        <circle cx="32" cy="32" r="27" fill="none" stroke="currentColor" strokeWidth="4" />
        <path d="M15 17h9l8 27 8-27h9" fill="none" stroke="currentColor" strokeWidth="4" strokeLinecap="round" strokeLinejoin="round" />
        <path d="M21 28l8 18h6l8-18" fill="none" stroke="currentColor" strokeWidth="4" strokeLinecap="round" strokeLinejoin="round" />
      </svg>
    );
  }

  if (type === 'honda') {
    return (
      <svg viewBox="0 0 64 64" className={common} role="img" aria-hidden="true">
        <rect x="12" y="9" width="40" height="46" rx="8" fill="none" stroke="currentColor" strokeWidth="4" />
        <path d="M22 18v28M42 18v28M22 32h20" fill="none" stroke="currentColor" strokeWidth="6" strokeLinecap="round" />
      </svg>
    );
  }

  if (type === 'suzuki') {
    return (
      <svg viewBox="0 0 64 64" className={common} role="img" aria-hidden="true">
        <path d="M42 7 17 25l18 8-17 25 29-22-18-8Z" fill="none" stroke="currentColor" strokeWidth="6" strokeLinejoin="round" />
      </svg>
    );
  }

  if (type === 'bmw') {
    return (
      <svg viewBox="0 0 64 64" className={common} role="img" aria-hidden="true">
        <circle cx="32" cy="32" r="27" fill="none" stroke="currentColor" strokeWidth="4" />
        <circle cx="32" cy="32" r="17" fill="none" stroke="currentColor" strokeWidth="3" />
        <path d="M32 15a17 17 0 0 1 17 17H32Z" fill="currentColor" />
        <path d="M32 32v17a17 17 0 0 1-17-17Z" fill="currentColor" />
      </svg>
    );
  }

  if (type === 'mercedes') {
    return (
      <svg viewBox="0 0 64 64" className={common} role="img" aria-hidden="true">
        <circle cx="32" cy="32" r="27" fill="none" stroke="currentColor" strokeWidth="4" />
        <path d="M32 11v23M32 34 13 48M32 34l19 14" fill="none" stroke="currentColor" strokeWidth="5" strokeLinecap="round" strokeLinejoin="round" />
      </svg>
    );
  }

  if (type === 'hyundai') {
    return (
      <svg viewBox="0 0 64 64" className={common} role="img" aria-hidden="true">
        <ellipse cx="32" cy="32" rx="28" ry="18" fill="none" stroke="currentColor" strokeWidth="4" />
        <path d="M22 43 29 21M35 43l7-22M26 33h14" fill="none" stroke="currentColor" strokeWidth="5" strokeLinecap="round" />
      </svg>
    );
  }

  return (
    <svg viewBox="0 0 64 64" className={common} role="img" aria-hidden="true">
      <ellipse cx="32" cy="32" rx="27" ry="15" fill="none" stroke="currentColor" strokeWidth="4" />
      <ellipse cx="32" cy="32" rx="10" ry="23" fill="none" stroke="currentColor" strokeWidth="4" />
      <ellipse cx="32" cy="32" rx="18" ry="8" fill="none" stroke="currentColor" strokeWidth="3" />
    </svg>
  );
}

function VehicleCard({ vehicle, featured = false }) {
  return (
    <motion.article layout initial={{ opacity: 0, scale: 0.96 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0, scale: 0.96 }} className="group overflow-hidden rounded-[2rem] border border-slate-200 bg-white shadow-sm transition hover:-translate-y-2 hover:shadow-glow dark:border-white/10 dark:bg-white/[0.055]">
      <div className="relative aspect-[16/10] overflow-hidden">
        <img src={vehicle.image} alt={vehicle.name} className="h-full w-full object-cover transition duration-700 group-hover:scale-110" />
        <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent" />
        <span className="absolute left-4 top-4 rounded-full border border-white/20 bg-black/35 px-3 py-1 text-xs text-white backdrop-blur-xl">{vehicle.category}</span>
      </div>
      <div className="p-6">
        <div className="flex items-start justify-between gap-4">
          <div>
            <h3 className="font-display text-xl font-semibold">{vehicle.name}</h3>
            <p className="mt-1 text-sm text-slate-500 dark:text-white/50">{vehicle.seats}</p>
          </div>
          <Car className="text-aurora" />
        </div>
        <div className="mt-5 flex flex-wrap gap-2">
          {vehicle.features.map((feature) => <span key={feature} className="rounded-full bg-slate-100 px-3 py-1 text-xs text-slate-600 dark:bg-white/10 dark:text-white/60">{feature}</span>)}
        </div>
        <div className="mt-6 flex items-center justify-between">
          <span className="text-sm font-semibold text-aurora">{vehicle.price}</span>
          <button className={featured ? 'premium-button !px-4 !py-2 text-sm' : 'rounded-full bg-slate-950 px-4 py-2 text-sm font-semibold text-white transition hover:bg-aurora dark:bg-white dark:text-ink'}>Book</button>
        </div>
      </div>
    </motion.article>
  );
}

function Testimonials() {
  const items = [
    ['due', 'due'],
    ['due', 'due'],
    ['due', 'due'],
  ];
  return (
    <section className="section bg-slate-100/70 dark:bg-white/[0.03]">
      <SectionHeader eyebrow="Testimonials" title="Trusted For High-Stakes Travel" />
      <div className="mx-auto grid max-w-7xl gap-5 px-5 lg:grid-cols-3">
        {items.map(([quote, person]) => (
          <Reveal key={person} className="rounded-[2rem] border border-slate-200 bg-white p-7 dark:border-white/10 dark:bg-white/[0.055]">
            <div className="flex gap-1 text-champagne">{Array.from({ length: 5 }).map((_, index) => <Star key={index} size={18} fill="currentColor" />)}</div>
            <p className="mt-6 text-lg leading-8 text-slate-700 dark:text-white/70">{quote}</p>
            <p className="mt-6 text-sm font-semibold text-aurora">{person}</p>
          </Reveal>
        ))}
      </div>
    </section>
  );
}

function LogoMarquee() {
  return (
    <section className="overflow-hidden border-y border-slate-200 bg-white py-7 dark:border-white/10 dark:bg-black/30">
      <motion.div animate={{ x: ['0%', '-50%'] }} transition={{ duration: 22, repeat: Infinity, ease: 'linear' }} className="flex w-max gap-12 px-5">
        {[...logos, ...logos, ...logos].map((logo, index) => (
          <span key={`${logo}-${index}`} className="font-display text-2xl font-semibold text-slate-300 dark:text-white/20">{logo}</span>
        ))}
      </motion.div>
    </section>
  );
}

function Contact() {
  const socials = [
    [Instagram, 'https://www.instagram.com/uvalley_/', 'Instagram'],
    [Linkedin, '#', 'LinkedIn'],
    [Facebook, 'https://www.facebook.com/profile.php?id=61590468117982', 'Facebook'],
    [Phone, contactDetails.phoneHref, 'WhatsApp'],
  ];
  return (
    <section id="contact" className="section">
      <SectionHeader eyebrow="Contact" title="Plan Your Next Premium Journey" text="Share your route, occasion and preferred vehicle. The UValley team will help shape the right travel experience." />
      <div className="mx-auto grid max-w-7xl gap-6 px-5 lg:grid-cols-[1.1fr_0.9fr]">
        <Reveal>
          <form className="rounded-[2rem] border border-slate-200 bg-white p-6 shadow-sm dark:border-white/10 dark:bg-white/[0.055]">
            <div className="grid gap-4 sm:grid-cols-2">
              {['Full Name', 'Phone', 'Email', 'Journey Type'].map((field) => <input key={field} className="light-input" placeholder={field} />)}
            </div>
            <textarea className="light-input mt-4 min-h-36 w-full resize-none" placeholder="Tell us about route, date, city and vehicle preference" />
            <button type="button" className="premium-button mt-5">Request Booking <ArrowRight size={18} /></button>
          </form>
        </Reveal>
        <Reveal className="space-y-5">
          <div className="grid min-h-64 place-items-center rounded-[2rem] border border-slate-200 bg-[linear-gradient(135deg,#111827,#4c1d95)] text-white shadow-glass dark:border-white/10">
            <div className="text-center">
              <MapPin className="mx-auto text-champagne" size={34} />
              <p className="mt-3 font-display text-xl font-semibold">Google Maps Placeholder</p>
            </div>
          </div>
          <div className="rounded-[2rem] border border-slate-200 bg-white p-6 dark:border-white/10 dark:bg-white/[0.055]">
            <InfoLine icon={Phone} text={contactDetails.phone} href={contactDetails.phoneHref} />
            <InfoLine icon={Mail} text={contactDetails.email} href={contactDetails.emailHref} />
            <InfoLine icon={MapPin} text={contactDetails.address} />
            <InfoLine icon={Clock3} text="Business Hours: 24/7 Support" />
            <div className="mt-5 flex gap-3">
              {socials.map(([Icon, href, label]) => <a key={label} href={href} target={href.startsWith('http') ? '_blank' : undefined} rel={href.startsWith('http') ? 'noreferrer' : undefined} className="icon-button shadow-glow" aria-label={label}><Icon size={18} /></a>)}
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
}

function InfoLine({ icon: Icon, text, href }) {
  const content = (
    <>
      <Icon size={18} className="shrink-0 text-aurora" />
      <span>{text}</span>
    </>
  );

  if (href) {
    return <a href={href} className="mb-3 flex items-center gap-3 text-sm text-slate-600 transition hover:text-aurora dark:text-white/60">{content}</a>;
  }

  return <div className="mb-3 flex items-center gap-3 text-sm text-slate-600 dark:text-white/60">{content}</div>;
}

function FinalCta() {
  return (
    <section className="px-5 py-20">
      <div className="mx-auto max-w-7xl overflow-hidden rounded-[2rem] bg-radial-premium p-8 text-white shadow-glass sm:p-12">
        <div className="grid items-center gap-8 lg:grid-cols-[1fr_auto]">
          <div>
            <h2 className="font-display text-3xl font-semibold sm:text-5xl">Move with precision, comfort and presence.</h2>
            <p className="mt-4 max-w-2xl text-white/60">Book UValley for airport transfers, corporate travel, weddings, tourism, rentals and premium group transport.</p>
          </div>
          <a href="#contact" className="premium-button justify-center">Start a Booking <ArrowRight size={18} /></a>
        </div>
      </div>
    </section>
  );
}

function Footer() {
  return (
    <footer className="border-t border-slate-200 bg-white px-5 py-12 dark:border-white/10 dark:bg-black/40">
      <div className="mx-auto grid max-w-7xl gap-8 md:grid-cols-4">
        <div>
          <div className="font-display text-2xl font-semibold">UValley</div>
          <p className="mt-4 text-sm leading-6 text-slate-600 dark:text-white/60">Premium travel experiences across India for individuals, businesses and events.</p>
        </div>
        <FooterCol title="Quick Links" items={navItems.map(([label]) => label)} />
        <FooterCol title="Services" items={services.slice(0, 5).map(([, title]) => title)} />
        <div>
          <h3 className="font-display font-semibold">Newsletter</h3>
          <div className="mt-4 flex rounded-full border border-slate-200 bg-slate-50 p-1 dark:border-white/10 dark:bg-white/5">
            <input className="min-w-0 flex-1 bg-transparent px-4 text-sm outline-none" placeholder="Email address" />
            <button className="rounded-full bg-aurora px-4 py-2 text-sm font-semibold text-white">Join</button>
          </div>
          <div className="mt-5 space-y-2 text-sm text-slate-600 dark:text-white/60">
            <a href={contactDetails.phoneHref} className="block hover:text-aurora">{contactDetails.phone}</a>
            <a href={contactDetails.emailHref} className="block hover:text-aurora">{contactDetails.email}</a>
          </div>
        </div>
      </div>
      <div className="mx-auto mt-10 flex max-w-7xl flex-col gap-4 border-t border-slate-200 pt-6 text-sm text-slate-500 dark:border-white/10 dark:text-white/40 sm:flex-row sm:items-center sm:justify-between">
        <span>Copyright 2026 UValley. All rights reserved.</span>
        <span>Instagram · LinkedIn · Facebook · WhatsApp</span>
      </div>
    </footer>
  );
}

function FooterCol({ title, items }) {
  return (
    <div>
      <h3 className="font-display font-semibold">{title}</h3>
      <div className="mt-4 space-y-3">
        {items.map((item) => <a href="#" key={item} className="block text-sm text-slate-600 hover:text-aurora dark:text-white/60">{item}</a>)}
      </div>
    </div>
  );
}

createRoot(document.getElementById('root')).render(<App />);
