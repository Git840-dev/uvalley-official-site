/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  darkMode: 'class',
  theme: {
    extend: {
      fontFamily: {
        sans: ['Inter', 'ui-sans-serif', 'system-ui', 'sans-serif'],
        display: ['Sora', 'Inter', 'ui-sans-serif', 'system-ui', 'sans-serif'],
      },
      colors: {
        ink: '#050510',
        graphite: '#0a0d18',
        aurora: '#8b5cf6',
        plasma: '#c084fc',
        frost: '#f8fafc',
        champagne: '#f2d7a0',
      },
      boxShadow: {
        glow: '0 0 40px rgba(139, 92, 246, 0.28)',
        glass: '0 24px 90px rgba(0, 0, 0, 0.32)',
      },
      backgroundImage: {
        'radial-premium':
          'radial-gradient(circle at 20% 15%, rgba(139, 92, 246, 0.28), transparent 32%), radial-gradient(circle at 84% 10%, rgba(14, 165, 233, 0.16), transparent 28%), linear-gradient(135deg, #050510 0%, #080b19 48%, #16102b 100%)',
      },
    },
  },
  plugins: [],
};
